# Deutsch.PH — German A1 to A2 Study App

A full interactive German study app for Filipino English speakers. Built to deploy on Vercel in under 2 minutes.

## Features
- 16-week study schedule with checkable tasks
- Grammar lessons (A1 + A2) with Filipino context
- Vocabulary flashcards (60+ words, English + Filipino translations)
- Writing tasks with model answers and practice area
- Speaking scripts and role plays
- 10-question quiz
- Study notifications (in-app pop-ups + browser notifications)
- Progress tracking saved to localStorage
- Daily streak tracker
- Mobile-friendly

## Deploy to Vercel (2 minutes)

### Option 1: Vercel CLI
```bash
npm install -g vercel
cd deutsch-app
vercel
```
Follow the prompts. Your app will be live at a `.vercel.app` URL.

### Option 2: Vercel Dashboard (no CLI)
1. Go to https://vercel.com and sign up / log in
2. Click "Add New Project"
3. Upload this folder (drag and drop or connect GitHub)
4. Click Deploy — done!

### Option 3: GitHub + Vercel (recommended for updates)
1. Create a GitHub repo and push this folder
2. Go to https://vercel.com → Import Git Repository
3. Select your repo → Deploy
4. Every push to main auto-deploys

## File structure
```
deutsch-app/
├── index.html      # Main app (HTML + CSS)
├── app.js          # All logic (schedule, quiz, notifications, etc.)
├── vercel.json     # Vercel routing config
└── README.md       # This file
```

## Enabling browser notifications
1. Open the deployed app
2. Go to Settings
3. Toggle "Browser notifications" ON
4. Click Allow when the browser asks for permission
5. Set your daily study time (e.g. 19:00)
6. Enable "Daily reminder"

## Customizing your week
1. Go to Settings
2. Change "Current week" to whichever week you are on
3. Your dashboard will show today's tasks for that week
